
clear all; close all; clc
addpath fcns fcns_MPC


%% TEST 0 - GAIT 

for gait = 0:5  % 0 = trot, 1 = bound, ..., 5 = crawl
    fprintf('\n--- Simulating gait %d ---\n', gait);

    %Parameters 
    p = get_params(gait);
    p.playSpeed = 1;
    p.flag_movie = 1;

    dt_sim = p.simTimeStep;
    SimTimeDuration = 4.5;  % [sec]
    MAX_ITER = floor(SimTimeDuration/p.simTimeStep);

    % desired trajectory (fixed to isolate gait influence)
    p.acc_d = 1;
    p.vel_d = [0.5; 0];
    p.yaw_d = 0;

    % Model Predictive Control
    if gait == 1
        [p,Xt,Ut] = fcn_bound_ref_traj(p);
    else
        [Xt,Ut] = fcn_gen_XdUd(0,[],[1;1;1;1],p);
    end

    % initialize logging
    tstart = 0;
    tend = dt_sim;
    [tout,Xout,Uout,Xdout,Udout,Uext,FSMout] = deal([]);

    h_waitbar = waitbar(0,'Calculating...');
    tic
    for ii = 1:MAX_ITER
        t_ = dt_sim * (ii-1) + p.Tmpc * (0:p.predHorizon-1);

        if gait == 1
            [FSM,Xd,Ud,Xt] = fcn_FSM_bound(t_,Xt,p);
        else
            [FSM,Xd,Ud,Xt] = fcn_FSM(t_,Xt,p);
        end

        [H,g,Aineq,bineq,Aeq,beq] = fcn_get_QP_form_eta(Xt,Ut,Xd,Ud,p);
        zval = qpSWIFT(sparse(H), g, sparse(Aeq), beq, sparse(Aineq), bineq);
        Ut = Ut + zval(1:12);

        [u_ext,p_ext] = fcn_get_disturbance(tstart,p);
        p.p_ext = p_ext;
        u_ext = 0 * u_ext;

        [t,X] = ode45(@(t,X)dynamics_SRB(t,X,Ut,Xd,0*u_ext,p),[tstart,tend],Xt);

        Xt = X(end,:)';
        tstart = tend;
        tend = tstart + dt_sim;

        lent = length(t(2:end));
        tout = [tout;t(2:end)];
        Xout = [Xout;X(2:end,:)];
        Uout = [Uout;repmat(Ut',[lent,1])];
        Xdout = [Xdout;repmat(Xd(:,1)',[lent,1])];
        Udout = [Udout;repmat(Ud(:,1)',[lent,1])];
        Uext = [Uext;repmat(u_ext',[lent,1])];
        FSMout = [FSMout;repmat(FSM',[lent,1])];

        waitbar(ii/MAX_ITER,h_waitbar,'Calculating...');
    end
    close(h_waitbar)
    fprintf('Calculation Complete for gait %d!\n', gait);
    toc

    % Animation
    videoName = sprintf('Video_test1_gait_%d.mp4', gait);
    [t,EA,EAd] = fig_animate(tout,Xout,Uout,Xdout,Udout,Uext,p, videoName);

    % Save Frame and Video
    imgName = sprintf('Test1_gait_%d.png', gait);

    saveas(gcf, fullfile(pwd, imgName));

end

%% TEST 1 - FRICTION
output_folder = 'Test1_friction';
if ~exist(output_folder, 'dir')
    mkdir(output_folder);
end

gait = 0;
friction_values = [0.2, 0.4, 0.6, 0.8];
friction_values = 0.8;

for i = 1:length(friction_values)
    mu = friction_values(i);
    fprintf('\n--- Simulating Gait %d with mu = %.1f ---\n', gait, mu);

    % Parameters
    p = get_params(gait);
    p.mu = mu;                  
    p.playSpeed = 1;
    p.flag_movie = 1;

    dt_sim = p.simTimeStep;
    SimTimeDuration = 4.5;
    MAX_ITER = floor(SimTimeDuration / dt_sim);

    % Desired trajectory
    p.acc_d = 1;
    p.vel_d = [0.5; 0];
    p.yaw_d = 0;

    % Initial state
    if gait == 1
        [p,Xt,Ut] = fcn_bound_ref_traj(p);
    else
        [Xt,Ut] = fcn_gen_XdUd(0,[],[1;1;1;1],p);
    end

    % Logging
    tstart = 0; tend = dt_sim;
    [tout,Xout,Uout,Xdout,Udout,Uext,FSMout] = deal([]);

    h_waitbar = waitbar(0,'Calculating...');
    tic
    for ii = 1:MAX_ITER
        t_ = dt_sim * (ii-1) + p.Tmpc * (0:p.predHorizon-1);

        if gait == 1
            [FSM,Xd,Ud,Xt] = fcn_FSM_bound(t_,Xt,p);
        else
            [FSM,Xd,Ud,Xt] = fcn_FSM(t_,Xt,p);
        end

        [H,g,Aineq,bineq,Aeq,beq] = fcn_get_QP_form_eta(Xt,Ut,Xd,Ud,p);
        zval = qpSWIFT(sparse(H), g, sparse(Aeq), beq, sparse(Aineq), bineq);
        Ut = Ut + zval(1:12);

        [u_ext,p_ext] = fcn_get_disturbance(tstart,p);
        p.p_ext = p_ext;
        u_ext = 0 * u_ext;

        [t,X] = ode45(@(t,X)dynamics_SRB(t,X,Ut,Xd,0*u_ext,p),[tstart,tend],Xt);
        Xt = X(end,:)';
        tstart = tend;
        tend = tstart + dt_sim;

        lent = length(t(2:end));
        tout = [tout; t(2:end)];
        Xout = [Xout; X(2:end,:)];
        Uout = [Uout; repmat(Ut', [lent,1])];
        Xdout = [Xdout; repmat(Xd(:,1)', [lent,1])];
        Udout = [Udout; repmat(Ud(:,1)', [lent,1])];
        Uext = [Uext; repmat(u_ext', [lent,1])];
        FSMout = [FSMout; repmat(FSM', [lent,1])];

        waitbar(ii / MAX_ITER, h_waitbar, 'Calculating...');
    end
    close(h_waitbar)
    toc

    % Animation
    video_filename = fullfile(output_folder, sprintf('FrictionTest_mu_%.1f.mp4', mu));
    [t,EA,EAd] = fig_animate(tout,Xout,Uout,Xdout,Udout,Uext,p, video_filename);

    % Save snapshot
    img_filename = fullfile(output_folder, sprintf('FrictionTest_mu_%.1f.png', mu));
    saveas(gcf, img_filename);
end

%% TEST 2 - MASS

output_folder = 'Test2_mass';
if ~exist(output_folder, 'dir')
    mkdir(output_folder);
end

gait = 0;  
mass_values = [10, 20, 40, 60]; 


for i = 1:length(mass_values)
    mass = mass_values(i);
    fprintf('\n--- Simulating Gait %d with mass = %d kg ---\n', gait, mass);

    % Parameters
    p = get_params(gait);
    p.mass = mass;               
    p.playSpeed = 1;
    p.flag_movie = 1;

    dt_sim = p.simTimeStep;
    SimTimeDuration = 4.5;
    MAX_ITER = floor(SimTimeDuration / dt_sim);

    % Desired trajectory
    p.acc_d = 1;
    p.vel_d = [0.5; 0];
    p.yaw_d = 0;

    % Initial condition
    if gait == 1
        [p,Xt,Ut] = fcn_bound_ref_traj(p);
    else
        [Xt,Ut] = fcn_gen_XdUd(0,[],[1;1;1;1],p);
    end

    % Logging
    tstart = 0; tend = dt_sim;
    [tout,Xout,Uout,Xdout,Udout,Uext,FSMout] = deal([]);

    h_waitbar = waitbar(0,'Calculating...');
    tic
    for ii = 1:MAX_ITER
        t_ = dt_sim * (ii-1) + p.Tmpc * (0:p.predHorizon-1);

        if gait == 1
            [FSM,Xd,Ud,Xt] = fcn_FSM_bound(t_,Xt,p);
        else
            [FSM,Xd,Ud,Xt] = fcn_FSM(t_,Xt,p);
        end

        [H,g,Aineq,bineq,Aeq,beq] = fcn_get_QP_form_eta(Xt,Ut,Xd,Ud,p);
        zval = qpSWIFT(sparse(H), g, sparse(Aeq), beq, sparse(Aineq), bineq);
        Ut = Ut + zval(1:12);

        [u_ext,p_ext] = fcn_get_disturbance(tstart,p);
        p.p_ext = p_ext;
        u_ext = 0 * u_ext;

        [t,X] = ode45(@(t,X)dynamics_SRB(t,X,Ut,Xd,0*u_ext,p),[tstart,tend],Xt);
        Xt = X(end,:)';
        tstart = tend;
        tend = tstart + dt_sim;

        lent = length(t(2:end));
        tout = [tout; t(2:end)];
        Xout = [Xout; X(2:end,:)];
        Uout = [Uout; repmat(Ut', [lent,1])];
        Xdout = [Xdout; repmat(Xd(:,1)', [lent,1])];
        Udout = [Udout; repmat(Ud(:,1)', [lent,1])];
        Uext = [Uext; repmat(u_ext', [lent,1])];
        FSMout = [FSMout; repmat(FSM', [lent,1])];

        waitbar(ii / MAX_ITER, h_waitbar, 'Calculating...');
    end
    close(h_waitbar)
    toc

    % Animation
    video_filename = fullfile(output_folder, sprintf('MassTest_%dkg.mp4', mass));
    [t,EA,EAd] = fig_animate(tout,Xout,Uout,Xdout,Udout,Uext,p, video_filename);

    % Save snapshot
    img_filename = fullfile(output_folder, sprintf('MassTest_%dkg.png', mass));
    saveas(gcf, img_filename);
end

%% TEST 3 - VELOCITY
output_folder = 'Test3_velocity';
if ~exist(output_folder, 'dir')
    mkdir(output_folder);
end

gait = 0; 
velocities = [0.2, 0.5, 1.0, 1.5];  % desired forward speeds

for i = 1:length(velocities)
    vel_d = velocities(i);
    fprintf('\n--- Simulating Gait %d with desired velocity = %.1f m/s ---\n', gait, vel_d);

    % Parameters
    p = get_params(gait);
    p.playSpeed = 1;
    p.flag_movie = 1;

    p.vel_d = [vel_d; 0]; 
    p.acc_d = 1;
    p.yaw_d = 0;

    dt_sim = p.simTimeStep;
    SimTimeDuration = 4.5;
    MAX_ITER = floor(SimTimeDuration / dt_sim);

    % Initial condition
    if gait == 1
        [p,Xt,Ut] = fcn_bound_ref_traj(p);
    else
        [Xt,Ut] = fcn_gen_XdUd(0,[],[1;1;1;1],p);
    end

    % Logging
    tstart = 0; tend = dt_sim;
    [tout,Xout,Uout,Xdout,Udout,Uext,FSMout] = deal([]);

    h_waitbar = waitbar(0,'Calculating...');
    tic
    for ii = 1:MAX_ITER
        t_ = dt_sim * (ii-1) + p.Tmpc * (0:p.predHorizon-1);

        if gait == 1
            [FSM,Xd,Ud,Xt] = fcn_FSM_bound(t_,Xt,p);
        else
            [FSM,Xd,Ud,Xt] = fcn_FSM(t_,Xt,p);
        end

        [H,g,Aineq,bineq,Aeq,beq] = fcn_get_QP_form_eta(Xt,Ut,Xd,Ud,p);
        zval = qpSWIFT(sparse(H), g, sparse(Aeq), beq, sparse(Aineq), bineq);
        Ut = Ut + zval(1:12);

        [u_ext,p_ext] = fcn_get_disturbance(tstart,p);
        p.p_ext = p_ext;
        u_ext = 0 * u_ext;

        [t,X] = ode45(@(t,X)dynamics_SRB(t,X,Ut,Xd,0*u_ext,p),[tstart,tend],Xt);
        Xt = X(end,:)';
        tstart = tend;
        tend = tstart + dt_sim;

        lent = length(t(2:end));
        tout = [tout; t(2:end)];
        Xout = [Xout; X(2:end,:)];
        Uout = [Uout; repmat(Ut', [lent,1])];
        Xdout = [Xdout; repmat(Xd(:,1)', [lent,1])];
        Udout = [Udout; repmat(Ud(:,1)', [lent,1])];
        Uext = [Uext; repmat(u_ext', [lent,1])];
        FSMout = [FSMout; repmat(FSM', [lent,1])];

        waitbar(ii / MAX_ITER, h_waitbar, 'Calculating...');
    end
    close(h_waitbar)
    toc

    % Animation
    video_filename = fullfile(output_folder, sprintf('VelocityTest_vd_%.1f.mp4', vel_d));
    [t,EA,EAd] = fig_animate(tout,Xout,Uout,Xdout,Udout,Uext,p, video_filename);

    % Save snapshot
    img_filename = fullfile(output_folder, sprintf('VelocityTest_vd_%.1f.png', vel_d));
    saveas(gcf, img_filename);
end
